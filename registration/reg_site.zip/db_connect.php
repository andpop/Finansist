<?php

mysql_connect('localhost', 'пользователь', 'пароль пользователя') or die('Ошибка соеденения с MySQL!');
mysql_select_db('база данных') or die ('Ошибка соеденения с базой данных MySQL!');
mysql_query('SET NAMES `utf8`'); // выставляем кодировку базы данных

?>